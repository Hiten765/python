def convert_case(s):
    lower = ""
    upper = ""
    toggle = ""

    for ch in s:
        
        if 'A' <= ch <= 'Z':
            lower += chr(ord(ch) + 32)
            upper += ch
            toggle += chr(ord(ch) + 32)
                          
        elif 'a' <= ch <= 'z':
            lower += ch
            upper += chr(ord(ch) - 32)
            toggle += chr(ord(ch) - 32)

        else:
            lower += ch
            upper += ch
            toggle += ch

    return lower, upper, toggle


text = input("Enter a string: ")

lowercase, uppercase, togglecase = convert_case(text)

print("Lower case :", lowercase)
print("Upper case :", uppercase)
print("Toggle case:", togglecase)
