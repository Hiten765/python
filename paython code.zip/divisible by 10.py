a=int(input("enter value:"))

if(a%10==0):
    print("Value is divisible by 10")
else:
    print("Value is not divisible by 10")
