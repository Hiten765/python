a=input("Enter Alphabet:")

b=a.upper()

print(b)

        
