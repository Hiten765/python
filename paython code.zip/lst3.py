import random


odd_numbers = [random.randrange(1,20000000 , 2) for _ in range(1000)]

print(odd_numbers)


even_numbers = [random.randrange(1, 20000000, 1) for _ in range(1000)]

print(even_numbers)
