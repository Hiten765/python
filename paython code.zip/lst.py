lst=[52,55,4,8,56,26,58]
lst.append(69)
print(lst)

lst.remove(55)
print(lst)

lst.pop(3)
print(lst)

C=lst.count(4)
print(C)

lst.sort()
print(lst)

lst.insert(2,99)
print(lst)






