Name=[("Raghuram",),("Ranjeet",),("Jogander",),"supriya","saloni"]

boys=0
girls=0

for i in Name:
    if isinstance(i,tuple):
        boys+=1
    else:
        girls+=1
        
print(f"Boys={boys}")
print(f"Girls={girls}")

 rollnos.append(roll)
    names.append(name)
    ages.append(age)
    
print(rollnos,names,ages)

    date=(10,1,2008)
date2=(10,2,2008)
dif=(date[0]-date2[0],date[1]-date2[1],date[2]-date2[2])
days=abs(dif[0]+ dif[1]*30+dif[2]*365)

print("Days=",days)

