l=int(input("Enter Length:"))
b=int(input("Enter Breadth:"))

area=l*b
perimeter=2*(l+b)

if(area>perimeter):
    print("area>perimeter")
else:
    print("area<perimeter")
