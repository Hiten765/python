Info=[("RL23","Raghav",19),("RL11","Priya",19),("RL53","zoya",18)]

Name=[]
Roll=[]
Age=[]

for [i,j,k] in Info:
    Roll.append(i)
    Name.append(j)
    Age.append(k)

print(Name)
print(Roll)
print(Age)

        
 
