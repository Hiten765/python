def add():
    N1=int(input("Enter Number : " ))
    N2=int(input("Enter Number : " ))
    print(N1+N2)
    
print("Calling Function")

add()

print("After Caliing Function")


    
