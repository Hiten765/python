a=int(input("Enter No.:"))

if(a>0):
      print("Absolute Value:",a)
else:
    print("Absolute Value:",-a) 
