a=int(input("Enter value no. 1:"))
b=int(input("Enter value no. 2:"))

if(a>b):
    print("a is larger and b is smaller")
else:
    print("b is larger and a is smaller")
