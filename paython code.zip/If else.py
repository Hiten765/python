A=int(input("Enter Age : " ))

if(A>18):
    print("Eligilible to vote")
else:
    print("NOt eligilible to vote")

