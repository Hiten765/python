Date1=[(11,2,2026)]
Date2=[(18,2,2026)]

dif=(date[0]-date2[0],date[1]-date2[1],date[2]-date2[2])

days=abs(dif[0]+ dif[1]*30+dif[2]*365)

print("Days=",days)



