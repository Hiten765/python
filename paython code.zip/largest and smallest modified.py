a=int(input("Enter value no. 1:"))
b=int(input("Enter value no. 2:"))
c=int(input("Enter value no. 3:"))

if(a>b and b>c):
    print("a is largest")
    print("c is smallest")
elif(a > c and c > b):
    print("a is largest")
    print("b is smallest")
elif(b>c and a>c):
    print("b is largest")
    print("c is smallest")
elif(b>c and c>a):
    print("b is largest")
    print("a is smallest")
elif(c>a and a>b):
    print("c is largest")
    print("b is smallest")
elif(c > b and b > a):
    print("c is largest")
    print("a is smallest")
else:
    print("all are equal")
