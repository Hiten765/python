x1=int(input("Enter value:"))
y1=int(input("Enter value:"))
x2=int(input("Enter value:"))
y2=int(input("Enter value:"))
x3=int(input("Enter value:"))
y3=int(input("Enter value:"))

if(((y2-y1)/(x2-x1))==((y3-y2)/(x3-x2))):
    print("all points are lying on the same straight line")
else:
    print("all points are not lying on the same straight line")
    


