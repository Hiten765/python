import random

a=random.randint(1,100)
print(a)

b=random.randrange(2000,294839394)
print(b)

c=random.random()
print(c)
