#List of 5 random odd integers
import random
odd_lst=[]
even_lst=[]
for i in range (5):
    odd_lst.append(random.randrange(1,99,2))
print("odd numbers list:", odd_lst)

for i in range(4):
     even_lst.append(random.randrange(2,100,2))
print("Even numbers list:", even_lst)

##Replace 3rd element of odd lst
odd_lst[2]=even_lst
print("Modified list is:", odd_lst)

#Flattened the odd list
flat_lst=[]
for i in range(len(odd_lst)):
    if(isinstance(odd_lst[i], list)):
        for j in range(len(odd_lst[i])):
                       flat_lst.append(odd_lst[i][j])
    else:
        flat_lst.append(odd_lst[i])

print("Flattened list is:", flat_lst)

#sort the list
flat_lst.sort()
print("The sorted list is:", flat_lst)
        
