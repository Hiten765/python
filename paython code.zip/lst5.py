import random


Num = [random.randrange(1,200) for _ in range(20)]

print(Num)

A=int(input("Enter the Value:"))

C=Num.count(A)

print(C)
