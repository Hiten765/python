print("dollar to rupee conversion")

def dollar_rupee():
    dollar=float(input("ente how many dollars:"))
    rupee=dollar*48.0
    print(dollar,"dollars is equal to:", rupee,"rupees")

dollar_rupee()