print("grams into kg conversion" )

def grm_kg():
    grm=int(input("enter how many grams: "))
    kg=grm/1000
    print(grm,"grams is equal to:", kg,"kg")

grm_kg()
    