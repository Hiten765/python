
print("addition")
def  add ():
    a=int(input("enter first number: "))
    b=int(input("enter second number:"))
    c=a+b
    print("sum is:",c)

add()    