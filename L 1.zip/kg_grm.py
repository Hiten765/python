print("kg into grams conversion" )

def kg_grams():
    kg=int(input("enter how many grams: "))
    grams=kg*1000
    print(kg,"kg is equal to:", grams,"grams")

kg_grams()