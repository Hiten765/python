print("dollar to pound conversion via rupee")

def dollar_pound():
    dollar=float(input("enter how many dollars:"))
    rupee=dollar*48.0
    pound=rupee/70.0
    print(dollar,"dollars is equal to:", pound,"pounds")

dollar_pound()    