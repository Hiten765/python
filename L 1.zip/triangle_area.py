print("ara of trinagle calculator")

def triangle_area():
    base=float(input("enter base of triangle:"))
    height=float(input("enter height of triangle:"))
    area=base*height*0.5
    print("area of triangle is:", area)
    
triangle_area()