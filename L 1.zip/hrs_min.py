print("hours to min conversion")

def hrs_min():
    hrs=int(input("enter how many hours: "))
    min=hrs*60
    print(hrs,"hours is equal to:", min)

hrs_min()    