print("circle area calculator")

def circle_area():
    radius=float(input("enter radius of circle:"))
    area=22/7*radius*radius
    print("area of circle is:", area)
    
circle_area()