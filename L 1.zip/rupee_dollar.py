print("rupee to dollar conversion")

def rupee_dollar():
    rupee=float(input("enter how many rupees:"))
    dollar=rupee/48.0
    print(rupee,"rupees is equal to:", dollar,"dollars")

rupee_dollar()