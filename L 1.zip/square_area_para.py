print("square area and parameter calculator")

def square_area_para():
    side=float(input("ente side of square:"))
    area=side*side
    parametr=4*side
    print("area of square is:", area)   
    print("perimeter of square is:", parametr)

square_area_para()    