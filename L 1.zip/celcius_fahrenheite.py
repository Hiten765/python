print("celcius into farenheit conversion")

def celcius_farenheite():
    celcius=float(input("how much celcius:"))
    farenheit=(celcius*9/5)+32
    print(celcius,"celcius is equal to:", farenheit,"farenheit")
    
celcius_farenheite()    