
print("arthematic operations")
print("addition")
def  add ():
    a=int(input("enter first number: "))
    b=int(input("enter second number:"))
    c=a+b
    print("sum is:",c)

add()

print("substraction")

def  sub ():
    a=int(input("enter first number: "))
    b=int(input("enter second number:"))
    c=a-b
    print("substraction is:",c)

sub()

print("multiplication")

def  multiply ():
    a=int(input("enter first number: "))
    b=int(input("enter second number:"))
    c=a*b
    print("multiplication is:",c)

multiply()

print("division")

def  divide ():
    a=int(input("enter first number: "))
    b=int(input("enter second number:"))
    c=a/b
    print("sum is:",c)

divide() 

