
def add() :

    a=int(input("enter number 1:"))
    b=float(input("enter number2:"))
    c=a+b
    print(a, "+", b, "=", c)
    # print()
""" print("answer =",c)

"""
add()

def sub():
    a=int(input("enter number 1:"))
    b=float(input("enter number2:"))
    c=a-b
    print(a, "-", b, "=", c)

sub()

def multiply():
    a=int(input("enter number 1:"))
    b=float(input("enter number2:"))
    c=a*b
    print(a, "*", b, "=", c)

multiply()

def division():
    a=int(input("enter number 1:"))
    b=float(input("enter number2:"))
    c=a/b
    print(a, "/", b, "=", c)

division()

def  modulus():
    a=int(input("enter number 1:"))
    b=float(input("enter number2:"))
    c=a%b
    print(a, "%", b, "=", c)

modulus()

def hrsmin():
    a=int(input("enter number of hours:"))
    b=a*60
    print(a,"hours in miniutes", b)

hrsmin()

def minhrs():
    a=int(input("enter number of min:"))
    b=a/60
    print(a,"hours in miniutes", b)

minhrs()

def d_$():
    
    a=int(input("enter how much dollar$:"))
    b=a*90
    print(a,"dollar in rupees", b)

d_$()

def rup_$():

    a=int(input("enter how much rupee"))
    b=a/90
    print(a,"dollar in rupees", b)

rup_$()

def  $_pound():
     a=int(input("enter how much dollar$:"))
    b=a*90
    print(a,"dollar in rupees", b)
    c=b/70
    print("dollar into pound",c)

$_pound()

def grm_kg():

    a=int(input("enter how much grm"))
    b=a/1000
    print(a,"grm in kg", b)

grm_kg()

def kg_grm():

    a=int(input("enter how much kg"))
    b=a*1000
    print(a,"kg in grm", b)

kg_grm()

    



