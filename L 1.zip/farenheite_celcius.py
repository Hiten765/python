print("farenheit into celcius conversion")

def farenheite_celcius():
    farenheite=float(input("how much farenheite:"))
    celcius=(farenheite-32)*5/9 
    print(farenheite,"farenheit is equal to:", celcius,"celcius")

farenheite_celcius()    