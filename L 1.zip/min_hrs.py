print("min to hours conversion")

def min_hrs():
    min=int(input("enter how many minutes: "))
    hrs=min/60
    print(min,"hours is equal to:", hrs)


min_hrs()